import os
import concurrent.futures
from typing import Dict, Tuple
from collections import defaultdict
import threading

def get_directory_size(path: str) -> float:
    """Calculate total size of a directory."""
    total = 0
    try:
        with os.scandir(path) as entries:
            for entry in entries:
                try:
                    if entry.is_file(follow_symlinks=False):
                        total += entry.stat(follow_symlinks=False).st_size
                    elif entry.is_dir(follow_symlinks=False):
                        total += get_directory_size(entry.path)
                except (OSError, PermissionError):
                    continue
    except (OSError, PermissionError):
        return 0
    return total

def format_size(size_in_bytes: float) -> str:
    """Format size in bytes to human readable format."""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_in_bytes < 1024:
            return f"{size_in_bytes:.2f} {unit}"
        size_in_bytes /= 1024
    return f"{size_in_bytes:.2f} PB"

def process_directory(path: str, current_depth: int, max_depth: int) -> Dict[str, Tuple[float, Dict]]:
    """Process a directory and return its size and structure."""
    if current_depth > max_depth:
        return {}
    
    result = {}
    try:
        # Get immediate subdirectories
        with os.scandir(path) as entries:
            dirs = [entry for entry in entries if entry.is_dir(follow_symlinks=False)]
            
            # Process each subdirectory
            for dir_entry in dirs:
                try:
                    dir_path = dir_entry.path
                    dir_size = get_directory_size(dir_path)
                    if dir_size > 100 * 1024 * 1024:  # Only include if larger than 100MB
                        subdirs = process_directory(dir_path, current_depth + 1, max_depth)
                        result[dir_entry.name] = (dir_size, subdirs)
                except (OSError, PermissionError):
                    continue
                    
    except (OSError, PermissionError):
        return {}
    
    # Sort by size, largest first
    return dict(sorted(result.items(), key=lambda x: x[1][0], reverse=True))

def print_directory_tree(structure: Dict[str, Tuple[float, Dict]], prefix: str = "", is_last: bool = True):
    """Print the directory structure in a tree-like format."""
    for i, (name, (size, subdirs)) in enumerate(structure.items()):
        is_last_item = i == len(structure) - 1
        current_prefix = prefix + ("└── " if is_last_item else "├── ")
        next_prefix = prefix + ("    " if is_last_item else "│   ")
        
        # Print current directory with size
        print(f"{current_prefix}{name} ({format_size(size)})")
        
        # Recursively print subdirectories
        if subdirs:
            print_directory_tree(subdirs, next_prefix, is_last_item)

def analyze_disk_space(root_path: str, max_depth: int = 3):
    """Analyze disk space usage and display results."""
    print(f"\nAnalyzing disk space usage in {root_path} (up to {max_depth} levels deep)")
    print("Only showing directories larger than 100MB\n")
    
    try:
        # Get root directory size
        root_size = get_directory_size(root_path)
        print(f"Total size: {format_size(root_size)}\n")
        
        # Process directory structure
        structure = process_directory(root_path, 0, max_depth)
        
        # Print the tree
        if structure:
            print("Directory Structure:")
            print_directory_tree(structure)
        else:
            print("No directories larger than 100MB found.")
            
    except Exception as e:
        print(f"Error analyzing directory: {e}")

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Analyze and display disk space usage')
    parser.add_argument('path', help='Root directory path to analyze')
    parser.add_argument('--depth', type=int, default=3, help='Maximum depth to scan (default: 3)')
    
    args = parser.parse_args()
    analyze_disk_space(args.path, args.depth)
